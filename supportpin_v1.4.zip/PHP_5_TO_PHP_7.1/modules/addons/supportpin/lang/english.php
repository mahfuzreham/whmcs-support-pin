<?php
$_ADDONLANG['nopin'] = "You didnt have generated a PIN";
$_ADDONLANG['havepin'] = "Your PIN is: ";
$_ADDONLANG['message'] = "To verificate the ownership of your accout please provide this PIN to our support. Your PIN is 24 hours valid.";
$_ADDONLANG['generatebutton'] = "Generate PIN";

// for sidebares at whmcs v6 / v7
$_ADDONLANG['sidebar_nopin'] = "No PIN Code generated.";
$_ADDONLANG['sidebar_havepin'] = "Your current PIN is: ";
$_ADDONLANG['sidebar_generatebutton'] = "Generate new PIN";
$_ADDONLANG['sidebar_title'] = "Support PIN";