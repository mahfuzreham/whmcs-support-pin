<?php
$_ADDONLANG['nopin'] = "Sie haben noch keinen PIN erstellt";
$_ADDONLANG['havepin'] = "Ihr aktueller PIN lautet: ";
$_ADDONLANG['message'] = "Um Ihre Identit&auml;t im Livechat zu best&auml;tigen, k&ouml;nnen Sie hier einen PIN-Code generieren. Der PIN ist aus Sicherheitsgr&uuml;nden nur 24 Stunden g&uuml;ltig.";
$_ADDONLANG['generatebutton'] = "PIN Generieren";

// for sidebares at whmcs v6 / v7
$_ADDONLANG['sidebar_nopin'] = "Noch kein PIN erstellt.";
$_ADDONLANG['sidebar_havepin'] = "Ihr aktueller PIN lautet: ";
$_ADDONLANG['sidebar_generatebutton'] = "PIN Generieren";
$_ADDONLANG['sidebar_title'] = "Support PIN";