<?php

/*
# WHMCS >= V6
# UPLOAD THIS FILE INTO: /includes/hooks
# IT WILL ADD AN MENU ENTRY AT THE PRIMARY NAVBAR "SUPPORT"
# MODIFY AS REQUIRED
*/

use WHMCS\View\Menu\Item as MenuItem;
 
add_hook('ClientAreaPrimaryNavbar', 1, function (MenuItem $primaryNavbar) {
    $client = Menu::context('client');
    // ONLY SHOW TO LOGGED IN USERS
    if (!is_null($primaryNavbar->getChild('Support')) AND !is_null($client)) {
        $primaryNavbar->getChild('Support')
            ->addChild('Support PIN', array(
                'label' => 'Support PIN',
                'uri' => 'index.php?m=supportpin',
                'order' => '100',
                ));
    }
})

?>